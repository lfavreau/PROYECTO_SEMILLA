package entidades;

import java.util.HashMap;

public class Inventario {
    private HashMap<String, Producto> productos;

    public Inventario() {
        productos = new HashMap<>();
    }

    public void agregarProducto(Producto producto) {
        if (producto == null) {
            System.out.println("No se puede agregar, error de creación del producto.");
        } else {
            Producto productoExistente = productos.get(producto.getId());
            if (productoExistente == null) {
                productos.put(producto.getId(), producto);
                System.out.println("Producto agregado correctamente.");
            } else {
                System.out.println("Ya existe un producto con el mismo ID.");
            }
        }
    }

    public void eliminarProducto(String id) {
        Producto productoExistente = productos.get(id);
        if (productoExistente == null) {
            System.out.println("No se puede eliminar, producto inexistente.");
        } else {
            productos.remove(id);
            System.out.println("Producto eliminado del inventario.");
        }
    }

    public Producto buscarProductoPorID(String id) {
        return productos.get(id);
    }

    public Producto buscarProductoPorNombre(String nombre) {
        for (Producto producto : productos.values()) {
            if (producto.getNombre().toLowerCase().equals(nombre.toLowerCase())) {
                return producto;
            }
        }
        return null;
    }

    public void listarProductos() {
        if (productos.isEmpty()) {
            System.out.println("No hay productos en el inventario.");
        } else {
            for (Producto producto : productos.values()) {
                System.out.println(producto.descripcionDetallada());
            }
        }
    }
}
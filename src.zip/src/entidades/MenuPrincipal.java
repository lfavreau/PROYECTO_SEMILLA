package entidades;

import interfaces.Menu;
import manejadores.ErrorManejador;
import java.util.Scanner;

public class MenuPrincipal implements Menu {

    private Inventario inventario;
    private Scanner scanner;

    public MenuPrincipal(Inventario inventario) {
        this.inventario = inventario;
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("1. Agregar producto");
            System.out.println("2. Eliminar producto");
            System.out.println("3. Buscar producto por ID o nombre");
            System.out.println("4. Listar todos los productos");
            System.out.println("5. Modificar producto");
            System.out.println("6. Salir");
            opcion = ErrorManejador.leerEntero(scanner, "Seleccione una opción: ");

            switch (opcion) {
                case 1:
                    agregarProducto();
                    break;
                case 2:
                    eliminarProducto();
                    break;
                case 3:
                    buscarProducto();
                    break;
                case 4:
                    listarProductos();
                    break;
                case 5:
                    modificarProducto();
                    break;
                case 6:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        } while (opcion != 6);
    }

    private void agregarProducto() {
        String id = ErrorManejador.leerCadena(scanner, "Ingrese el ID del producto: ");
        if (inventario.buscarProductoPorID(id) != null) {
            System.out.println("Ya existe un producto con el mismo ID.");
            return;
        }
        String nombre = ErrorManejador.leerCadena(scanner, "Ingrese el nombre del producto: ");
        String descripcion = ErrorManejador.leerCadena(scanner, "Ingrese la descripción del producto: ");
        int precio = ErrorManejador.leerEntero(scanner, "Ingrese el precio del producto: ");
        int cantidadStock = ErrorManejador.leerEntero(scanner, "Ingrese la cantidad en stock: ");

        Producto nuevoProducto = new Producto(id, nombre, descripcion, precio, cantidadStock);
        inventario.agregarProducto(nuevoProducto);
        System.out.println("Producto agregado correctamente.");
    }

    private void eliminarProducto() {
        String id = ErrorManejador.leerCadena(scanner, "Ingrese el ID del producto a eliminar: ");
        inventario.eliminarProducto(id);
    }

    private void buscarProducto() {
        String input = ErrorManejador.leerCadena(scanner, "Ingrese el ID o nombre del producto que desea buscar: ");

        Producto producto;
        if (input.matches("\\d+")) {
            producto = inventario.buscarProductoPorID(input);
        } else {
            producto = inventario.buscarProductoPorNombre(input);
        }

        if (producto != null) {
            System.out.println(producto.descripcionDetallada());
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private void modificarProducto() {
        String id = ErrorManejador.leerCadena(scanner, "Ingrese el ID del producto que desea modificar: ");
        Producto producto = inventario.buscarProductoPorID(id);

        if (producto != null) {
            System.out.println("Producto encontrado: " + producto.descripcionDetallada());

            String nuevoNombre = ErrorManejador.leerCadena(scanner, "Ingrese el nuevo nombre del producto (actual: " + producto.getNombre() + "): ");
            producto.setNombre(nuevoNombre);
            String nuevaDescripcion = ErrorManejador.leerCadena(scanner, "Ingrese la nueva descripción del producto (actual: " + producto.getDescripcion() + "): ");
            producto.setDescripcion(nuevaDescripcion);
            int nuevoPrecio = ErrorManejador.leerEntero(scanner, "Ingrese el nuevo precio del producto (actual: $" + producto.getPrecio() + "): ");
            producto.setPrecio(nuevoPrecio);
            int nuevaCantidadStock = ErrorManejador.leerEntero(scanner, "Ingrese la nueva cantidad en stock (actual: " + producto.getCantidadStock() + "): ");
            producto.setCantidadStock(nuevaCantidadStock);
            System.out.println("Producto modificado correctamente: " + producto.descripcionDetallada());
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    private void listarProductos() {
        inventario.listarProductos();
    }
}
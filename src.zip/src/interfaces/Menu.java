package interfaces;

public interface Menu {
    void mostrarMenu();
}
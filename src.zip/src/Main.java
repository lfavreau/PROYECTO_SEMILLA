import entidades.*;
import interfaces.Menu;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        Random random = new Random();
        int contadorID = 1;

                // semillas nativas y nombres científicos
        String[][] arbolesNativos = {
                {"Pimiento", "Schinus areira"},
                {"Tamarugo", "Strombocarpa tamarugo"},
                {"Algarrobo", "Neltuma chilensis"},
                {"Patagua", "Crinodendron patagua"},
                {"Quillay", "Quillaja saponaria"},
                {"Litre", "Lithrea caustica"},
                {"Peumo", "Cryptocarya alba"},
                {"Boldo", "Peumus boldus"},
                {"Espino", "Vachellia caven"},
                {"Belloto", "Beilschmiedia miersii"},
                {"Molle", "Schinus latifolius"},
                {"Naranjillo", "Citronella mucronata"},
                {"Mayu", "Sophora macrocarpa"},
                {"Palma", "Jubaea chilensis"},
                {"Roble", "Nothofagus obliqua"},
                {"Hualo", "Nothofagus glauca"},
                {"Rauli", "Nothofagus alpina"},
                {"Radal", "Lomatia hirsuta"},
                {"Laurel", "Laurelia sempervirens"},
                {"Avellanillo", "Lomatia dentata"},
                {"Lingue", "Persea lingue"},
                {"Maqui", "Aristotelia chilensis"},
                {"Canelillo", "Pitavia punctata"},
                {"Canelo", "Drimys winteri"},
                {"Avellano", "Gevuina avellana"},
                {"Arrayan", "Luma apiculata"},
                {"Olivillo", "Aextoxicon punctatum"},
                {"Luma", "Amomyrtus luma"},
                {"Ulmo", "Eucryphia cordifolia"},
                {"Romerillo", "Lomatia ferruginea"},
                {"Alerce", "Fitzroya cupressoides"},
                {"Lenga", "Nothofagus pumilio"},
                {"Araucaria", "Araucaria araucana"},
                {"Ciruelillo", "Embothrium coccineum"}
        };

        // iniciar stock y precios aleatorio
        for (String[] arbol : arbolesNativos) {
            String nombreComun = arbol[0];
            String nombreCientifico = arbol[1];
            String id =  String.valueOf(contadorID);
            int precio = 100 + random.nextInt(1000); // aleatorio 100 base
            int cantidadStock = random.nextInt(100); // stock aleatorio entre 0 y 100

            Producto semilla = new Producto(id, nombreComun, nombreCientifico, precio, cantidadStock);
            inventario.agregarProducto(semilla);

            contadorID++;


        }

        // iniciailazr el menú
        Menu menu = new MenuPrincipal(inventario);
        menu.mostrarMenu();
    }
}
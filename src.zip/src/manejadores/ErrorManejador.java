package manejadores;

import java.util.Scanner;

public class ErrorManejador {

    public static int leerEntero(Scanner scanner, String mensaje) {
        int numero = -1;
        boolean esValido = false;

        do {
            System.out.print(mensaje);
            String entrada = scanner.nextLine();
            try {
                numero = Integer.parseInt(entrada);
                esValido = true;
            } catch (NumberFormatException e) {
                System.out.println("Error: El valor ingresado no es numérico. Intente de nuevo.");
            }
        } while (!esValido);

        return numero;
    }

    public static String leerCadena(Scanner scanner, String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }
}